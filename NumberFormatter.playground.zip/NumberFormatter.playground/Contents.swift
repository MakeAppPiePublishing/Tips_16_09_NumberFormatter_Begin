// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 16 (Q4 2021) video 09
//  by Steven Lipton (C)2020, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//This Week:  Number and list formatters
//  For more code, go to http://bit.ly/AppPieGithub

import UIKit

// Basic Number Formatting
let radius = 5
let radiusSq = radius * radius
var area = Double.pi * Double(radiusSq)
var volume = area * 100.0


//Locales
let loc = "en_US" // try en_US, fr_FR, ar,ur_in

//Currency
let cur = "USD" // try USD,EUR,INR,JPY,ISK(Iceland Krona)

// List formatters
let words = ["Mozzarella","Basil","Tomatoes"]
let numbers = [12.30, 0.090, 112.116]
